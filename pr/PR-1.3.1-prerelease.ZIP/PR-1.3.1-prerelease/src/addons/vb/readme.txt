This folder contains the interface to import pr to a visual basic project.
Just include pr.bas module.
There is a sample project in the sample folder. There you will also find
a compiled version of pr.dll that matches with the interface.
The interfaces are a bit old, but we will upgrade them and recompile it.
